package com.example.poi_chart;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xddf.usermodel.chart.*;
import org.apache.poi.xssf.usermodel.*;

/**
 * mvn compile
 * mvn exec:java -Dexec.mainClass="com.example.poi_chart.ExcelChartGenerator"
 */
public class ExcelChartGenerator {

    // データ: 日本の過去5年間の人口推移 (単位: 万人)
    private static final String[] YEARS = {"2021", "2022", "2023", "2024", "2025"};
    private static final double[] POPULATION = {12568, 12512, 12451, 12390, 12329};

    public static void main(String[] args) {
        try {
            System.out.println("Excelファイルの出力を開始します...");

            // 1. Chart.jsの画像(解像度違い)を貼り付けたブックを作成 (幅 x 高さ)
            createWorkbookWithChartImage("Population_3000x4000.xlsx", 3000, 3000);
            createWorkbookWithChartImage("Population_1500x2000.xlsx", 2000, 1500);
            createWorkbookWithChartImage("Population_750x1000.xlsx", 1000, 750);
            createWorkbookWithChartImage("Population_500x375.xlsx", 500, 375);
            createWorkbookWithChartImage("Population_250x190.xlsx", 250, 190);

            // 2. Excelネイティブのグラフを挿入したブックを作成
            long tsStart = System.currentTimeMillis();
            for (int i=0; i<1000; i++) {
                createWorkbookWithExcelNativeChart("out/Population_NativeChart_" + i + ".xlsx");
            }
            long tsEnd = System.currentTimeMillis();
            System.out.println("total = " + (tsEnd - tsStart)/1000.0);
            
            System.out.println("すべてのExcelファイルの出力が完了しました！");
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Chart.js(QuickChart API)で生成した画像を指定解像度で取得し、Excelに貼り付ける
     */
    private static void createWorkbookWithChartImage(String fileName, int width, int height) throws Exception {
        try (Workbook wb = new XSSFWorkbook();
             FileOutputStream fos = new FileOutputStream(fileName)) {
            
            Sheet sheet = wb.createSheet("Chart Image");

            // QuickChart APIを使用してChart.jsの画像をバイト配列で取得
            byte[] imageBytes = getChartImageBytes(width, height);

            // 画像をブックに追加
            int pictureIdx = wb.addPicture(imageBytes, Workbook.PICTURE_TYPE_PNG);
            CreationHelper helper = wb.getCreationHelper();
            Drawing drawing = sheet.createDrawingPatriarch();
            ClientAnchor anchor = helper.createClientAnchor();
            
            // B2セル(Row=1, Col=1)を左上の起点に画像を配置
            anchor.setCol1(1);
            anchor.setRow1(1);
            Picture pict = drawing.createPicture(anchor, pictureIdx);
            
            // 取得した画像データの元の解像度サイズでシートに展開する
            pict.resize();

            wb.write(fos);
        }
    }

    /**
     * QuickChart API を呼び出して Chart.js 互換の画像データを取得する
     */
    private static byte[] getChartImageBytes(int width, int height) throws Exception {
        File f = new File("img", "chart_" + width + "x" + height + ".png");
        if (!f.exists()) {
            throw new RuntimeException("not found file " + f);
        }

        if (!f.exists()) {
            // Chart.jsのコンフィグレーションをJSONで作成
            String chartConfig = "{"
                    + "\"type\":\"line\","
                    + "\"data\":{"
                    + "\"labels\":[\"2021\",\"2022\",\"2023\",\"2024\",\"2025\"],"
                    + "\"datasets\":[{\"label\":\"日本の人口推移 (万人)\",\"data\":[12568,12512,12451,12390,12329],\"fill\":false,\"borderColor\":\"blue\"}]"
                    + "}"
                    + "}";
            
            // JSONをURLエンコード
            String encodedConfig = URLEncoder.encode(chartConfig, StandardCharsets.UTF_8.toString());
            
            // サイズ指定を付与したURLを作成
            String urlString = String.format("https://quickchart.io/chart?w=%d&h=%d&c=%s", width, height, encodedConfig);

            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            try (InputStream is = conn.getInputStream()) {
            }
        }
        
        // 画像データをbyte配列として読み込む
        try (InputStream is = new FileInputStream(f)) {
            return IOUtils.toByteArray(is);
        }
    }

    /**
     * Excelのネイティブ機能 (XDDF) を使用してグラフを作成する
     */
    private static void createWorkbookWithExcelNativeChart(String fileName) throws Exception {
        try (XSSFWorkbook wb = new XSSFWorkbook();
             FileOutputStream fos = new FileOutputStream(fileName)) {
            
            XSSFSheet sheet = wb.createSheet("Native Chart");

            // --- 1. シートに元データを書き込む ---
            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("年");
            headerRow.createCell(1).setCellValue("人口 (万人)");

            for (int i = 0; i < YEARS.length; i++) {
                Row row = sheet.createRow(i + 1);
                row.createCell(0).setCellValue(YEARS[i]);
                row.createCell(1).setCellValue(POPULATION[i]);
            }

            // --- 2. グラフの描画領域 (アンカー) を作成 ---
            XSSFDrawing drawing = sheet.createDrawingPatriarch();
            // D2セル から K16セル あたりにグラフを配置
            XSSFClientAnchor anchor = drawing.createAnchor(0, 0, 0, 0, 3, 1, 10, 15);
            XSSFChart chart = drawing.createChart(anchor);
            chart.setTitleText("日本の過去5年間の人口推移");
            chart.setTitleOverlay(false);

            // --- 3. 軸の設定 ---
            XDDFCategoryAxis bottomAxis = chart.createCategoryAxis(AxisPosition.BOTTOM);
            bottomAxis.setTitle("年");
            XDDFValueAxis leftAxis = chart.createValueAxis(AxisPosition.LEFT);
            leftAxis.setTitle("人口 (万人)");
            leftAxis.setCrosses(AxisCrosses.AUTO_ZERO);

            // --- 4. データソースの指定 (シートのセル範囲とリンク) ---
            XDDFDataSource yearsData = XDDFDataSourcesFactory.fromStringCellRange(sheet, new CellRangeAddress(1, 5, 0, 0));
            XDDFNumericalDataSource popData = XDDFDataSourcesFactory.fromNumericCellRange(sheet, new CellRangeAddress(1, 5, 1, 1));

            // --- 5. 折れ線グラフとしてプロット ---
            XDDFLineChartData data = (XDDFLineChartData) chart.createData(ChartTypes.LINE, bottomAxis, leftAxis);
            XDDFLineChartData.Series series = (XDDFLineChartData.Series) data.addSeries(yearsData, popData);
            series.setTitle("人口 (万人)", null);
            series.setSmooth(false); // 直線で結ぶ

            chart.plot(data);
            wb.write(fos);
        }
    }
}
