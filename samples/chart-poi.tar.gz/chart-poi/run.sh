mvn compile && mvn exec:java -Dexec.mainClass="com.example.poi_chart.ExcelChartGenerator"

