const fs = require('fs');
const { ChartJSNodeCanvas } = require('chartjs-node-canvas');

/*
 15K population_500x375.png
 25K population_750x562.5.png
 86K population_1000x750.jpg
 33K population_1000x750.png
2.9M population_1000x750.tiff

 75K population_2000x1500.png
172K population_4000x3000.png

1000 ファイル作成
total: 51.177s
  --> 0.051177 s/ 1file

*/
function generate_config(scale) {
  const configuration = {
    type: 'bar',
    data: {
      labels: ['1990', '2012', '2025', '2060'],
      datasets: [
        {
          label: '75歳以上',
          data: [5, 12, 18, 27],
          fill: true,
          borderColor: 'blue',
          borderWidth: 2 * scale, // 倍率に合わせて線も太くする
          backgroundColor: 'blue',
          tension: 0.1
        },
        {
          label: '65歳以上74歳以下',
          data: [7, 12, 12, 13],
          fill: true,
          borderColor: 'orange',
          borderWidth: 2 * scale, // 倍率に合わせて線も太くする
          backgroundColor: 'orange',
          tension: 0.1
        },
        {
          label: '20歳以上64歳以下',
          data: [61, 58, 54, 47],
          fill: true,
          borderColor: 'green',
          borderWidth: 2 * scale, // 倍率に合わせて線も太くする
          backgroundColor: 'green',
          tension: 0.1
        },
        {
          label: '19歳以下',
          data: [26, 18, 15, 13],
          fill: true,
          borderColor: 'cyan',
          borderWidth: 2 * scale, // 倍率に合わせて線も太くする
          backgroundColor: 'cyan',
          tension: 0.1
        },
      ]
    },
    options: {
      indexAxis: 'y',
      // 倍率に合わせて文字サイズを動的に変更することでレイアウト崩れを防ぐ
      plugins: {
        title: {
          display: true,
          text: '日本の過去5年間の人口推移',
          font: { size: 24 * scale }
        },
        legend: {
          labels: { font: { size: 16 * scale } }
        }
      },
      scales: {
        x: { stacked: true, ticks: { font: { size: 14 * scale } } },
        y: { stacked: true, ticks: { font: { size: 14 * scale } } }
      }
    }
  };
  return configuration;
}

async function main() {
    console.log('グラフ画像の出力を開始します...');

    // ベースとなる解像度
    const baseWidth = 1000;
    const baseHeight = 750;

    // 出力したい倍率 (1倍, 2倍, 4倍)
    const scales = [0.5, 0.75, 1, 2, 4];

    for (const scale of scales) {
        // 出力解像度の計算
        const width = baseWidth * scale;
        const height = baseHeight * scale;

        // ChartJSNodeCanvasの初期化 (白背景を設定)
        const chartJSNodeCanvas = new ChartJSNodeCanvas({ 
            width, 
            height, 
            backgroundColour: 'white' 
        });

        // Chart.js のコンフィグレーション
        // https://www.mhlw.go.jp/file/05-Shingikai-10801000-Iseikyoku-Soumuka/0000055150.pdf
        // 人口ピラミッドの変化
        const configuration = generate_config(scale);

        // 画像バッファを生成
        const buffer = await chartJSNodeCanvas.renderToBuffer(configuration);

        // ファイルに保存
        const fileName = `population_${width}x${height}.png`;
        fs.writeFileSync(fileName, buffer);
        console.log(`${fileName} を出力しました。`);
    }
    console.time("total");
    for (i=0; i< 1000; i++) {
      const scale = 1;
        // 出力解像度の計算
        const width = baseWidth * scale;
        const height = baseHeight * scale;

        // ChartJSNodeCanvasの初期化 (白背景を設定)
        const chartJSNodeCanvas = new ChartJSNodeCanvas({ 
            width, 
            height, 
            backgroundColour: 'white' 
        });

        // Chart.js のコンフィグレーション
        // https://www.mhlw.go.jp/file/05-Shingikai-10801000-Iseikyoku-Soumuka/0000055150.pdf
        // 人口ピラミッドの変化
        const configuration = generate_config(scale);

        // 画像バッファを生成
        const buffer = await chartJSNodeCanvas.renderToBuffer(configuration);

        // ファイルに保存
        const fileName = `out/population_${width}x${height}_${i}.png`;
        fs.writeFileSync(fileName, buffer);
    }
    console.timeEnd("total");
    console.log('すべての画像の出力が完了しました！');
}

main();
